import React, { Component } from 'react';
import { Grid, Cell } from 'react-mdl';
import Education from './education';
import Experience from './experience';
import Skills from './skills';


class Resume extends Component {
  render() {
    return(
      <div>
        <Grid>
          <Cell col={4}>
            <div style={{textAlign: 'center'}}>
              <img
                src="https://www.shareicon.net/download/2015/09/18/103157_man_512x512.png"
                alt="avatar"
                style={{height: '200px'}}
                 />
            </div>

            <h2 style={{paddingTop: '2em'}}>Krunal Durne</h2>
            <h4 style={{color: 'grey'}}>Front End Developer</h4>
            <hr style={{borderTop: '3px solid #833fb2', width: '50%'}}/>
            <p>Since beginning my journey as a freelance Front End Developer nearly 2 years ago, I've done remote work for Companies, consulted for startups, and collaborated with talented people to create digital products for both business and consumer use. I'm quietly confident, naturally curious, and perpetually working on improving my chops one design problem at a time.</p>
            <hr style={{borderTop: '3px solid #833fb2', width: '50%'}}/>
            <h5>Address</h5>
            <p>302 Ram Nagar Mumbai, 444221</p>
            <h5>Phone</h5>
            <p>(805) 002-00812</p>
            <h5>Email</h5>
            <p>xyz@gmail.com</p>
            <h5>Web</h5>
            <p>-//-</p>
            <hr style={{borderTop: '3px solid #833fb2', width: '50%'}}/>
          </Cell>
          <Cell className="resume-right-col" col={8}>
            <h2>Education</h2>


            <Education
              // startYear={2002}
              endYear={2011}
              schoolName="B.C.A"
              schoolDescription="(Bachelor of Computer Application) with First division."
               />

               <Education
                //  startYear={2007}
                 endYear={2015}
                 schoolName="M.C.A"
                 schoolDescription="(Master of Computer Application) with First division."
                  />
                <hr style={{borderTop: '3px solid #e22947'}} />

              <h2>Experience</h2>

            <Experience
              // startYear={}
              endYear={2015}
              jobName="Crazy Mind Tech pvt.ltd, (Internship)"
              jobDescription="Project Name: – N.G.O – non government organisation ( child labour) .
              Technologies: HTML 5, CSS3, Bootstrap, JavaScript."
              />

              <Experience
                // startYear={2012}
                endYear={2016}
                jobName="Second Job"
                jobDescription="-/****************************/-"
                />
              <hr style={{borderTop: '3px solid #e22947'}} />
              <h2>Skills</h2>
              <Skills
                skill="HTML5"
                progress={85}
                />
                <Skills
                  skill="Css3"
                  progress={83}
                  />
                  <Skills
                  skill="Bootstrap"
                  progress={90}
                  />
                  <Skills
                  skill="Materialize"
                  progress={70}
                  />
                  <Skills
                    skill="Sass"
                    progress={70}
                    />
                    <Skills
                      skill="ReactJs"
                      progress={60}
                      />
          </Cell>
        </Grid>
      </div>
    )
  }
}

export default Resume;
